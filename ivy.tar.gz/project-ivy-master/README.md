# Project Ivy

## Project Motivation

- [Quick Overview](docs/OVERVIEW.md)
- [Architecture Guide](docs/ARCHITECTURE.md)

## License

Project Ivy is a VMware project that is developed and open sourced under the [Apache 2.0](https://www.apache.org/licenses/LICENSE-2.0).

### Disclaimer

- Project Ivy is intended to represent a reference implementation of what a modern application platform **could** look like.  There
are several other decisions that go into making an application platform "production ready".  Ivy is not intended to produce a
production ready application platform, rather give an opinionated, sample view of what one may look like.

- Project Ivy is not supported by VMware.  It is a tool that belongs to Cloud Native Readiness and is intended to be used by
the field to help customers get acquainted with Kubernetes and the decisions that go into producing a fully fledged application platform.
Once again, the platform produced by Ivy is a reference only and not intended to be production ready out of the box.

## Getting Started

Interested in deploying?  View the getting started guide to deploy Ivy at [docs/QUICKSTART.md](docs/QUICKSTART.md)

## Contributing Guide

Interested in contributing? View the contributing guide at [docs/CONTRIBUTING.md](docs/CONTRIBUTING.md)
