# Project Ivy Components

## Platform Profile

The following components are displayed in the order they will be deployed to a TKG cluster.  Additional tuning and behavior can be changed by adding additional variables to your `build/inventory.yaml`.

| Component Name | Documentation |
| --- | --- |
| workload-tenancy | [README.md](../roles/workload-tenancy/README.md) |
| networking | [README.md](../roles/networking/README.md) |
| security | [README.md](../roles/security/README.md) |
| admission-control | [README.md](../roles/admission-control/README.md) |
| storage | [README.md](../roles/storage/README.md) |
| dns | [README.md](../roles/dns/README.md) |
| ingress | [README.md](../roles/ingress/README.md) |
| identity | [README.md](../roles/identity/README.md) |
| monitoring | [README.md](../roles/monitoring/README.md) |
| container-registry | [README.md](../roles/container-registry/README.md) |
| logging | [README.md](../roles/logging/README.md) |
| secret-management/hashicorp-vault | [README.md](../roles/secret-management/hashicorp-vault/README.md) |
| secret-management/etcd-encryption | [README.md](../roles/secret-management/etcd-encryption/README.md) |
| application-stack | [README.md](../roles/application-stack/README.md) |
| application-pipeline | [README.md](../roles/application-pipeline/README.md) |
| service-mesh/istio | [README.md](../roles/service-mesh/istio/README.md) |

## Advanced Profile

The following components are displayed in the order they will be deployed to a TKG cluster.  Additional tuning and behavior can be changed by adding additional variables to your `build/inventory.yaml`.

| Component Name | Documentation |
| --- | --- |
| networking | [README.md](../roles/networking/README.md) |
| container-registry | [README.md](../roles/container-registry/README.md) |
| extensions/tanzu-mission-control | [README.md](../roles/extensions/tanzu-mission-control/README.md) |
| extensions/avi | [README.md](../roles/extensions/avi/README.md) |
| extensions/spring-cloud-gateway | [README.md](../roles/extensions/spring-cloud-gateway/README.md) |
| extensions/spring-cloud-data-flow | [README.md](../roles/extensions/spring-cloud-data-flow/README.md) |
| extensions/tanzu-application-catalog | [README.md](../roles/extensions/tanzu-application-catalog/README.md) |
| extensions/tanzu-build-service | [README.md](../roles/extensions/tanzu-build-service/README.md) |
| extensions/tanzu-observability | [README.md](../roles/extensions/tanzu-observability/README.md) |
| extensions/tanzu-service-mesh | [README.md](../roles/extensions/tanzu-service-mesh/README.md) |
| extensions/tanzu-sql | [README.md](../roles/extensions/tanzu-sql/README.md) |
