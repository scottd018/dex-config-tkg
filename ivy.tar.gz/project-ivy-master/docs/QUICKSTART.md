# Quick Start

- [Quick Start](#quick-start)
  - [TKG Installation](#tkg-installation)
  - [Administrative Access](#administrative-access)
  - [Provider Specific Steps](#provider-specific-steps)

## TKG Installation

Prior to running the commands to deploy Project Ivy, it is required that you have a pre-existing
TKG **workload** cluster deployed.  Please follow the appropriate documentation on the VMware website at
https://docs.vmware.com/en/VMware-Tanzu-Kubernetes-Grid/1.2/vmware-tanzu-kubernetes-grid-12/GUID-tanzu-k8s-clusters-create.html in order to deploy your first TKG workload cluster.

**NOTE:** *Deploying Project Ivy to a management cluster is not supported at this time.*

**NOTE:** *In this current iteration, TKG* **MUST** *be deployed to an internet-connected environment. Air-gapped
deployments may be looked at to extend functionality of Project Ivy in future releases.*


## Administrative Access

Once your TKG workload cluster is deployed, you will need to ensure that your kubeconfig file, (located at
`~/.kube/config` by default) provides administrative access to your TKG cluster.  If you setup your
first TKG workload cluster in the previous step, you will need to ensure that you have run the
`tkg get credentials <my_cluster_name>` command to ensure that the context exists for your TKG
workload cluster in your kubeconfig file.


## Cloud Provider Specific Steps

Start here by clicking your cloud provider type once you have a TKG workload cluster online.

- [AWS Instructions](providers/aws.md)
- [Azure Instructions](providers/azure.md)
- [KIND Instructions](providers/kind.md)
- [VMware Instructions](providers/vmware.md)
