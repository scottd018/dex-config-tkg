# Azure Provider Documentation

## Table of Contents

- [Super Quick Start](#super-quick-start)
- [Detailed Quick Start](#detailed-quick-start)
   - [1. Create Cluster Inventory](#1-create-cluster-inventory)
   - [2. Set Variables](#2-set-variables)
     - [2a. Common Variables](#2a-common-variables)
       - [Common Variable Table](#common-variable-table)
     - [2b. Azure Variables](#2b-azure-variables)
     - [2c. Additional/Optional Variables (Expert)](#2c-additionaloptional-variables-expert)
       - [Project Ivy Components](#project-ivy-components)
         - [Platform Profile](#platform-profile)
         - [Advanced Profile](#advanced-profile)
   - [3. Tanzu Mission Control Provisioned Cluster Additional Instructions](#3-tanzu-mission-control-provisioned-cluster-additional-instructions)
   - [4. Build Project Ivy Container Image](#4-build-project-ivy-container-image)
   - [5. Deploy Project Ivy to Your TKG Cluster](#5-deploy-project-ivy-to-your-tkg-cluster)
     - [Deploy Project Ivy](#deploy-project-ivy)

## Super Quick Start

1. `make setup.azure` - create the inventory file with global variables.

1. `vim build/inventory.yaml` - edit and update the variables.

1. `make build` - build an image for deploying Project Ivy.

1. `make deploy` - deploy Project Ivy.

## Detailed Quick Start

This guide will take you through all of the necessary steps to prepare for and to deploy Project Ivy.

### 1. Create Cluster Inventory

A custom inventory will need to be created in order to define which cluster(s) you will be
deploying Project Ivy to.  This inventory file is a [standard Ansible inventory file, in YAML
format](https://docs.ansible.com/ansible/latest/user_guide/intro_inventory.html#inventory-basics-formats-hosts-and-groups).  The inventory file additionally contains all of the necessary variables that feed into the deployment process.

To create your inventory file, run the following command:

```bash
make setup.azure
```

> **NOTE:** The command above will drop your inventory file example at `build/inventory.yaml`.  If you need the inventory file at another location,
> you can run `INVENTORY=/path/to/my/inventory.yaml make setup.aws` for example.  Be sure that the `INVENTORY` variable matches this for following
> build and deploy steps.

### 2. Set Variables

After creating your inventory file, you will need to modify required variables that fit your environment needs:

```bash
vim build/inventory.yaml
```

#### 2a. Common Variables

##### Common Variable Table
Common variables, regardless of provider type, that will need to be modified are as follows:

| Variable Name         | Variable Type | Required | Default Value | Description                                                                              |
| --------------------- | ------------- | -------- | ------------- | ---------------------------------------------------------------------------------------- |
| ivy_profile           | string        | true     | (none)        | Name of the Project Ivy profile (collection of cluster components) to deploy . Can be set to `platform` or `advanced`. See the contribution guide for more details on profiles [here](../CONTRIBUTING.md#profiles). |
| ivy_demo              | boolean       | true     | false         | Whether or not to install Project Ivy demo content onto the cluster after the main profile components have deployed. |
| tanzu_cluster_name    | string        | true     | (none)        | The DNS friendly name (e.g. no underscores or special characters) of the cluster         |
| tanzu_default_tls_provider | string | true | "ca" | The default method for ingress TLS certificate deployment.  Can be set to `"ca"`, `"letsencrypt-stage"`, or `"letsencrypt-prod"`  See [Ingress TLS Certificates](../tls/tls.md) for expanded information on each setting. |
| tanzu_dns_provider    | string        | true     | route53       | The DNS provider/backend. Currently `route53`, `internal`, `xip.io`, and `local` are valid options.  See [Choosing the Appropriate DNS Solution](../DNS.md) for expanded information on each setting. |
| tanzu_ingress_domain  | string        | true     | (none)        | The ingress domain, which will be used to add ingress DNS records to                     |
| tanzu_kubectl_context | string        | true     | (none)        | The kubectl context (from kubeconfig) which represents the TKG target deployment cluster |

#### 2b. Azure Variables

TKG clusters which are hosted on Azure should modify cluster variables (represented in the
inventory as `azure_tanzu_cluster1`) specific to Azure.

Common variables, specific to the Azure provider type, that will need modified are as follows:

| Variable Name | Variable Type | Required | Default Value | Description |
| --- | --- | --- | --- | --- |
| tanzu_storage_classes_azure | list of dicts | true (azure only) | `[]` | See docs at [Storage README](../roles/storage/README.md) and raw vars at `../roles/storage/common/vars/main.yaml` for examples. |

#### 2c. Additional/Optional Variables (Expert)

In most cases you will not need to manipulate any of the preset variables for Project Ivy components.  However, you may encounter edge cases where the behavior of a component needs to be tuned or modified to affect how it is deployed into your cluster.  This is a rare circumstance, but if you would like to delve into all the possible configuration options for the deployment of Project Ivy, see each of the component specific documentation pages from the table below.

##### Project Ivy Components

###### Platform Profile

The following components are displayed in the order they will be deployed to a TKG cluster.  Additional tuning and behavior can be changed by adding additional variables to your `build/inventory.yaml`.

| Component Name | Documentation |
| --- | --- |
| workload-tenancy | [README.md](../../roles/workload-tenancy/README.md) |
| networking | [README.md](../../roles/networking/README.md) |
| security | [README.md](../../roles/security/README.md) |
| admission-control | [README.md](../../roles/admission-control/README.md) |
| storage | [README.md](../../roles/storage/README.md) |
| ingress | [README.md](../../roles/ingress/README.md) |
| identity | [README.md](../../roles/identity/README.md) |
| monitoring | [README.md](../../roles/monitoring/README.md) |
| container-registry | [README.md](../../roles/container-registry/README.md) |
| logging | [README.md](../../roles/logging/README.md) |
| autoscaling | [README.md](../../roles/autoscaling/README.md) |
| secret-management/hashicorp-vault | [README.md](../../roles/secret-management/hashicorp-vault/README.md) |
| application-stack | [README.md](../../roles/application-stack/README.md) |
| application-pipeline | [README.md](../../roles/application-pipeline/README.md) |

###### Advanced Profile

The following components are displayed in the order they will be deployed to a TKG cluster.  Additional tuning and behavior can be changed by adding additional variables to your `build/inventory.yaml`.

| Component Name | Documentation |
| --- | --- |
| networking | [README.md](../../roles/networking/README.md) |
| container-registry | [README.md](../../roles/container-registry/README.md) |
| extensions/tanzu-mission-control | [README.md](../../roles/extensions/tanzu-mission-control/README.md) |
| extensions/spring-cloud-gateway | [README.md](../../roles/extensions/spring-cloud-gateway/README.md) |
| extensions/spring-cloud-data-flow | [README.md](../../roles/extensions/spring-cloud-data-flow/README.md) |
| extensions/tanzu-application-catalog | [README.md](../../roles/extensions/tanzu-application-catalog/README.md) |
| extensions/tanzu-build-service | [README.md](../../roles/extensions/tanzu-build-service/README.md) |
| extensions/tanzu-observability | [README.md](../../roles/extensions/tanzu-observability/README.md) |
| extensions/tanzu-sql | [README.md](../../roles/extensions/tanzu-sql/README.md) |

### 3. Tanzu Mission Control Provisioned Cluster Additional Instructions

If your cluster is a TMC-provisioned cluster, the following steps need to be performed:

1. Install the TMC binary.  See https://docs.vmware.com/en/VMware-Tanzu-Mission-Control/services/tanzumc-using/GUID-7EEBDAEF-7868-49EC-8069-D278FD100FD9.html.

1. `tmc login`

1. When launching the `make deploy` command in the steps following, ensure that you run it with `TMC=true`

For example:

```bash
TMC=true make deploy
```

### 4. Build Project Ivy Container Image

Build a Docker image to run the Ansible playbooks.  This will relieve you of the need to install the Python dependencies locally.  To build the Docker image with the latest state of the project locally, run:

```bash
make build
```

To build this Docker image with custom image names (default: ivy) and image versions (default: latest), run the
following, being sure to substitute in your desired variables appropriately:

```bash
IMAGE=ivy-custom VERSION=v1.0.0 make build
```

> **NOTE:** *If using custom names, ensure that these match during the deploy stage.*

### 5. Deploy Project Ivy to Your TKG Cluster

At this point, you should have completed all the necessary prerequisite work to deploy Project Ivy to your workload cluster.  You are now ready to Deploy Project Ivy.

#### Deploy Project Ivy

You can deploy using the docker image with the latest state of the project locally.  To do so, run:

```bash
make deploy
```

To run when using custom image names, image versions, and/or inventory run the following, being sure to substitute your desired variables appropriately:

```bash
INVENTORY=/path/to/my/inventory.yaml IMAGE=ivy-test VERSION=v1.0.0 make deploy
```

> **NOTE:** *If you are deploying Project Ivy to a Tanzu Mission Control provisioned cluster, you must run the following version of the command:*

```bash
TMC=true make deploy
```
