In most cases you will not need to manipulate any of the preset variables for Project Ivy components.  However, you may encounter edge cases where the behavior of a component needs to be tuned or modified to affect how it is deployed into your cluster.  This is a rare circumstance, but if you would like to delve into all the possible configuration options for the deployment of Project Ivy, see each of the component specific documentation pages from the table below.

##### Project Ivy Components

###### Platform Profile

The following components are displayed in the order they will be deployed to a TKG cluster.  Additional tuning and behavior can be changed by adding additional variables to your `build/inventory.yaml`.

| Component Name | Documentation |
| --- | --- |
| workload-tenancy | [README.md](../../roles/workload-tenancy/README.md) |
| networking | [README.md](../../roles/networking/README.md) |
| security | [README.md](../../roles/security/README.md) |
| admission-control | [README.md](../../roles/admission-control/README.md) |
| storage | [README.md](../../roles/storage/README.md) |
| ingress | [README.md](../../roles/ingress/README.md) |
| identity | [README.md](../../roles/identity/README.md) |
| monitoring | [README.md](../../roles/monitoring/README.md) |
| container-registry | [README.md](../../roles/container-registry/README.md) |
| logging | [README.md](../../roles/logging/README.md) |
| autoscaling | [README.md](../../roles/autoscaling/README.md) |
| secret-management/hashicorp-vault | [README.md](../../roles/secret-management/hashicorp-vault/README.md) |
| application-stack | [README.md](../../roles/application-stack/README.md) |
| application-pipeline | [README.md](../../roles/application-pipeline/README.md) |

###### Advanced Profile

The following components are displayed in the order they will be deployed to a TKG cluster.  Additional tuning and behavior can be changed by adding additional variables to your `build/inventory.yaml`.

| Component Name | Documentation |
| --- | --- |
| networking | [README.md](../../roles/networking/README.md) |
| container-registry | [README.md](../../roles/container-registry/README.md) |
| extensions/tanzu-mission-control | [README.md](../../roles/extensions/tanzu-mission-control/README.md) |
| extensions/spring-cloud-gateway | [README.md](../../roles/extensions/spring-cloud-gateway/README.md) |
| extensions/spring-cloud-data-flow | [README.md](../../roles/extensions/spring-cloud-data-flow/README.md) |
| extensions/tanzu-application-catalog | [README.md](../../roles/extensions/tanzu-application-catalog/README.md) |
| extensions/tanzu-build-service | [README.md](../../roles/extensions/tanzu-build-service/README.md) |
| extensions/tanzu-observability | [README.md](../../roles/extensions/tanzu-observability/README.md) |
| extensions/tanzu-sql | [README.md](../../roles/extensions/tanzu-sql/README.md) |
