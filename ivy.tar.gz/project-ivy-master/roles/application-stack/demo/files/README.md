store manifests and configs in this directory
