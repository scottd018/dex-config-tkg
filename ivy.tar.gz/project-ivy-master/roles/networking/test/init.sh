#!/bin/bash

CURRENT_DIR=`pwd`
SCRIPT_DIR=$(dirname $0)

cd $SCRIPT_DIR
ln -s ../../../roles/ roles && ansible-playbook -vv ./playbook.yaml -i ./inventory.yaml
unlink roles
cd $CURRENT_DIR

