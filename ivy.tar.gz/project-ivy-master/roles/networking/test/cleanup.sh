#!/bin/bash

# cleanup vmware
kubectl config use-context infra-dev-admin@infra-dev
kubectl delete globalnetworkpolicy tanzu-global-deny-all

# cleanup aws
kubectl config use-context tkg-mgmt-aws-20200526143618-admin@tkg-mgmt-aws-20200526143618
kubectl delete globalnetworkpolicy tanzu-global-deny-all
