#!/bin/bash
echo "Make sure you update the ./inventory file to suit your environment!"
echo "./ansible.cfg contains a default Ansible configuration with the yaml stdout callback turned on for prettified output..."
ansible-playbook uninstall.yaml -i ./inventory
